package com.sise.framework.core;

import java.util.List;

import com.sise.framework.web.QueryPage;

import net.sf.json.JSONObject;

public interface BaseService<T,Long> {
	/**
	 * 查询列表
	 * @param obj
	 * @return
	 */
	public List<JSONObject> getList(T obj,QueryPage queryPage);
	
	/**
	 * 根据内容查询json记录
	 * @param obj
	 * @return
	 */
	public JSONObject getEntityByObj(T obj);
	
	/**
	 * 根据Id给出记录
	 * @param entity
	 * @return
	 */
	public T getEntityById(Long id);
	
	/**
	 * 查询条数
	 * @param obj
	 * @return
	 */
	public Integer getCount(T obj);
	
	/**
	 * 批量更新数据
	 * @param list
	 */
	public void doSave(List list);
	
	/**
	 * 单个更新数据
	 * @param list
	 */
	public void doSave(T obj);
	
	/**
	 * 根据ID删除
	 * @param id
	 */
	public void doDelete(String id);
}