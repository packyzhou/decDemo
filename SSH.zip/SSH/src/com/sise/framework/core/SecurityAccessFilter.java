package com.sise.framework.core;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * 安全认证过滤器，在web.xml中配置，指定对哪些路径进行过滤。
 */
public class SecurityAccessFilter implements Filter {
	
	private Log log=LogFactory.getLog(this.getClass());

	public void destroy() {
		
	}
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		HttpServletRequest request=(HttpServletRequest) arg0;
		HttpServletResponse response=(HttpServletResponse) arg1;
		String uri=request.getRequestURI();
		BeanFactory beans = WebApplicationContextUtils.getWebApplicationContext(request.getSession().getServletContext());
		arg2.doFilter(arg0, arg1);
	}

	

	/**
	 * @param request
	 * @param uri
	 * @return
	 */
	private boolean authorityURL(HttpServletRequest request, String uri) {
		
		return true;
	}
	public void init(FilterConfig arg0) throws ServletException {
		
	}
}
