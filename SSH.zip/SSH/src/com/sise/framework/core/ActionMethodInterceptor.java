package com.sise.framework.core;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.StrutsStatics;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

/**
 * 捕捉action异常
 */
public class ActionMethodInterceptor extends MethodFilterInterceptor {

	/**
	 * 
	 */
	private Log log=LogFactory.getLog(this.getClass());
	private static final long serialVersionUID = 1L;

	/* (non-Javadoc)
	 * @see com.opensymphony.xwork2.interceptor.MethodFilterInterceptor#doIntercept(com.opensymphony.xwork2.ActionInvocation)
	 */
	@Override
	protected String doIntercept(ActionInvocation invocation) throws Exception {
		HttpServletRequest request = (HttpServletRequest) ActionContext.getContext().get(StrutsStatics.HTTP_REQUEST); 
		String result="error";
		try {
			result=invocation.invoke();
		}catch(Exception e){
			log.error(e);
			request.setAttribute("exceptionObject", e);
			e.printStackTrace();
		}
		return result;
	}

}

