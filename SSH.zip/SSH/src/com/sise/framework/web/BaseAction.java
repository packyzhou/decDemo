package com.sise.framework.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import com.sise.framework.common.ConfigContext;
import com.sise.framework.utils.AjaxUtils;
import com.sise.framework.utils.DateUtils;
import com.sise.framework.utils.NumberUtils;
import com.sise.java.entity.User;

/**
 * ACTION基类，系统中所有ACTION都建议继承此类或其子类
 */
public class BaseAction extends ActionSupport implements Preparable, ServletRequestAware, ServletResponseAware {

	private static final long serialVersionUID = -7063330644867832575L;
	
	protected Log log=LogFactory.getLog(this.getClass());
	protected HttpServletResponse response;
	protected HttpServletRequest request;
	protected QueryPage queryPage = null;// 用于分页
	private String returnPath;
	
	protected User user ;
	
	/**
	 * action跳转action
	 */
	private String actionName;//action名
	private String actionMethod;//方法
	private String actionParam;//值

	public final static String LOGOUT = "logout";
	public final static String LOGIN = "login";
	public final static String INPUT = "input";
	public final static String ERROR = "error";
	
	
	/*
	 * 预处理方法，访问ACTION中的方法前都会先调用此方法 (non-Javadoc)
	 * 
	 * @see com.opensymphony.xwork2.Preparable#prepare()
	 */
	public void prepare() throws Exception {
		if (request.getParameter("rows") != null) {
			queryPage = new QueryPage(request);
		}
		User userSession = (User) request.getSession().getAttribute("user");
		if(userSession!=null)
		{
			user = userSession;
		}
	}
	
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}


	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	public String redirect(String path) {
		returnPath = path;
		return "redirect";
	}
	
	public String dispatcher(String path) {
		returnPath = path;
		return "dispatcher";
	}
	
	public String actionChain(String actionName,String actionMethod,String actionParam) {
		this.actionName = actionName;
		this.actionMethod = actionMethod;
		this.actionParam = actionParam;
		return "actionChain";
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getActionMethod() {
		return actionMethod;
	}

	public void setActionMethod(String actionMethod) {
		this.actionMethod = actionMethod;
	}

	public String getActionParam() {
		return actionParam;
	}

	public void setActionParam(String actionParam) {
		this.actionParam = actionParam;
	}

	public String getReturnPath() {
		return returnPath;
	}

	public void setReturnPath(String returnPath) {
		this.returnPath = returnPath;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	protected void uploadFile(String fileName,List<File> file){
//		String fileName = DateUtils.getDate("yyyyMMddHHmmss")+NumberUtils.getRandom(4)+".jpg";//文件名
		String upPath = ConfigContext.UPLOAD_ULR;
		byte[] bs=null;
		try {
			String uploadPath = upPath+ DateUtils.getDate("yyyyMM") + "/";//文件目录
			if(null != file.get(0)){
			File tempFile = file.get(0);
			
				
				InputStream is = null;
				OutputStream ops = null;
				try {
					is = new FileInputStream(tempFile);
					
					File destDir=new File(uploadPath);
					if(!destDir.exists()){
						destDir.mkdirs();
					}
					File destFile = new File(uploadPath+fileName);
					ops = new FileOutputStream(destFile);
					IOUtils.copy(is, ops);
					
				} catch (Exception ex) {
					ex.printStackTrace();
				} finally {
					IOUtils.closeQuietly(is);
					IOUtils.closeQuietly(ops);
				}
				
		
			File file111 = new File(uploadPath+fileName);
			
			bs = IOUtils.toByteArray(new FileInputStream(file111));
			
			
//			response.sendRedirect(new String(Base64.encode("{\"status\":\"1\",\"errMsg\":\"上传成功！\"}".getBytes("UTF-8"))));
			AjaxUtils.renderSuccess("上传成功！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			AjaxUtils.renderSuccess("上传失败！");
		}
	}
}
