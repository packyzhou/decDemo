/**
 * 
 */
package com.sise.framework.utils;

import java.io.UnsupportedEncodingException;

import org.apache.commons.lang.StringUtils;

/**
 * 系统平台常用工具类
 */
public class Utility {
	/**
	 * 截取固定长度的字符串
	 * @param str
	 * @param count 
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String subFixString(String str, int count) throws UnsupportedEncodingException{
		if(StringUtils.isBlank(str) || StringUtils.isEmpty(str)){
			return null;
		}
		int byteCount=0;
		StringBuffer sb=new StringBuffer();
		for (int i = 0; i < str.length(); i++) {
			char c=str.charAt(i);
			byte[] b=String.valueOf(c).getBytes("UTF-8");
			if(b.length==3){
				count--;
			}else{
				byteCount++;
				if(byteCount==2){
					count--;
					byteCount=0;
				}
			}
			sb.append(c);
			if(count<=0){
				break;
			}
		}
		String result=sb.toString();
		if(str.length()>result.length()){
			result=result+"...";
		}
		return result;
	}
	
	// 检查是否是图片格式
	public static boolean checkIsImage(String imgStr) {
		boolean flag = false;
		if (imgStr != null) {
			if (imgStr.equalsIgnoreCase(".gif")
					|| imgStr.equalsIgnoreCase(".jpg")
					|| imgStr.equalsIgnoreCase(".jpeg")
					|| imgStr.equalsIgnoreCase(".png")) {
				flag = true;
			}
		}
		return flag;
	}
}
