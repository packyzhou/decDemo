package com.sise.framework.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;

/**
 * 数据安全加密工具类
 */
public class SecurityUtils {
	
	/**
	 * 对输入的字符串进行MD5加密
	 * @param str 需要加密的字符串
	 * @return MD5加密后的字符串
	 */
	public static String getMD5(String str) {
		if(StringUtils.isEmpty(str)){
			return null;
		}
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			byte[] digest = messageDigest.digest(str.getBytes());
			return new String(Hex.encodeHex(digest));
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
	}
	
	public static void main(String[] args) {
		System.out.println(getMD5("33"));
	}
}
