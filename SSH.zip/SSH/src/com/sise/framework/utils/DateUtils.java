package com.sise.framework.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 日期格式转换，处理工具
 */
public class DateUtils {
	private static Log log=LogFactory.getLog(DateUtils.class);
	private static int x;                  // 日期属性：年   
    private static int y;                  // 日期属性：月   
    private static int z;                  // 日期属性：日  
	/**
	 * 按照指定的格式，将日期类型对象转换成字符串，例如：yyyy-MM-dd,yyyy/MM/dd,yyyy/MM/dd hh:mm:ss
	 * 如果传入的日期为null,则返回空值
	 * 
	 * @param date
	 *            日期类型对象
	 * @param format
	 *            需转换的格式
	 * @return 日期格式字符串
	 */
	public static String formatDate(Date date, String format) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat formater = new SimpleDateFormat(format);
		return formater.format(date);
	}

	/**
	 * 将日期类型对象转换成yyyy-MM-dd类型字符串 如果传入的日期为null,则返回空值
	 * 
	 * @param date
	 *            日期类型对象
	 * @return 日期格式字符串
	 */
	public static String formatDate(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		return formater.format(date);
	}

	/**
	 * 将日期类型对象转换成yyyy-MM-dd HH:mm:ss类型字符串 如果传入的日期为null,则返回空值
	 * 
	 * @param date
	 *            日期类型对象
	 * @return 日期格式字符串
	 */
	public static String formatTime(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formater.format(date);
	}

	/**
	 * 按照指定的格式，将字符串解析成日期类型对象，例如：yyyy-MM-dd,yyyy/MM/dd,yyyy/MM/dd hh:mm:ss
	 * 
	 * @param dateStr
	 *            日期格式的字符串
	 * @param format
	 *            字符串的格式
	 * @return 日期类型对象
	 */
	public static Date parseDate(String dateStr, String format) {
		if (StringUtils.isEmpty(dateStr)) {
			return null;
		}
		SimpleDateFormat formater = new SimpleDateFormat(format);
		try {
			return formater.parse(dateStr);
		} catch (ParseException e) {
			log.error(e);
		}
		return null;
	}
	
	public static Date parseDateTime(String dateStr) {
		if (StringUtils.isEmpty(dateStr)) {
			return null;
		}
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			return formater.parse(dateStr);
		} catch (ParseException e) {
			log.error(e);
		}
		return null;
	}
	
	public static Date parseDateTimeShort(String dateStr) {
		if (StringUtils.isEmpty(dateStr)) {
			return null;
		}
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		try {
			return formater.parse(dateStr);
		} catch (ParseException e) {
			log.error(e);
		}
		return null;
	}

	/**
	 * 将字符串（yyyy-MM-dd）解析成日期
	 * 
	 * @param dateStr
	 *            日期格式的字符串
	 * @return 日期类型对象
	 */
	public static Date parseDate(String dateStr) {
		return parseDate(dateStr, "yyyy-MM-dd");
	}

	/**
	 * 获取当前年份
	 * 
	 * @return int
	 */
	public static int getYear() {
		return Calendar.getInstance().get(Calendar.YEAR);
	}

	/**
	 * 获取当前月份
	 * 
	 * @return int
	 */
	public static int getMonth() {
		return Calendar.getInstance().get(Calendar.MONTH) + 1;
	}

	/**
	 * 获取当前月份
	 * 
	 * @return int
	 */
	public static int getDay() {
		return Calendar.getInstance().get(Calendar.DATE);
	}

	/**
	 * 判断两个日期是否为同一天
	 * 
	 * @param date1
	 *            日期类型对象1
	 * @param date2
	 *            日期类型对象2
	 * @return true or false
	 */
	public static boolean isSameDay(Date date1, Date date2) {
		if (date1 == null || date2 == null) {
			return false;
		}
		if (formatDate(date1).equals(formatDate(date2))) {
			return true;
		}
		return false;
	}

	/**
	 * 判断两个日期是否为同一月
	 * 
	 * @param date1
	 *            日期类型对象1
	 * @param date2
	 *            日期类型对象2
	 * @return true or false
	 */
	public static boolean isSameMonth(Date date1, Date date2) {
		if (date1 == null || date2 == null) {
			return false;
		}
		if (formatDate(date1, "yyyy-MM").equals(formatDate(date2, "yyyy-MM"))) {
			return true;
		}
		return false;
	}

	/**
	 * 判断两个日期是否为同一年
	 * 
	 * @param date1
	 *            日期类型对象1
	 * @param date2
	 *            日期类型对象2
	 * @return true or false
	 */
	public static boolean isSameYear(Date date1, Date date2) {
		if (date1 == null || date2 == null) {
			return false;
		}
		if (formatDate(date1, "yyyy").equals(formatDate(date2, "yyyy"))) {
			return true;
		}
		return false;
	}

	/**
	 * 根据指定的格式（例如：yyyy-MM-dd）获取当天的时间字符串
	 * 
	 * @return 日期字符串
	 */
	public static String getDate(String format) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		String strDate = sdf.format(date);
		return strDate;
	}

	/**
	 * 根据指定的格式（例如：yyyy-MM-dd）获取昨天的时间字符串
	 * 
	 * @return 日期字符串
	 */
	public static String getYesterday(String format) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -1);
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		String strDate = sdf.format(cal.getTime());
		return strDate;
	}

	/**
	 * 对指定的日期增加或减少指定的小时数
	 * 
	 * @param date
	 *            需要修改的日期对象
	 * @param amount
	 *            需要修改的数量，如果需要增加一小时，amount=1,如果减少一小时，amount=-1;
	 * @return 修改后日期类型对象
	 */
	public static Date addHour(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR, amount);
		return cal.getTime();
	}

	/**
	 * 对指定的日期增加或减少指定的天数
	 * 
	 * @param date
	 *            需要修改的日期对象
	 * @param amount
	 *            需要修改的数量，如果需要增加一天，amount=1,如果减少一天，amount=-1;
	 * @return 修改后日期类型对象
	 */
	public static Date addDay(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, amount);
		return cal.getTime();
	}

	/**
	 * 对指定的日期增加或减少指定的月数
	 * 
	 * @param date
	 *            需要修改的日期对象
	 * @param amount
	 *            需要修改的数量，如果需要增加一个月，amount=1,如果减少一个月，amount=-1;
	 * @return 修改后日期类型对象
	 */
	public static Date addMonth(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, amount);
		return cal.getTime();
	}

	/**
	 * 计算两个日期相隔的小时数
	 * 
	 * @param date1
	 *            日期对象1
	 * @param date2
	 *            日期对象2
	 * @return 两个日期相隔的小时数
	 */
	public static double getHours(Date date1, Date date2) {
		if (date1 == null || date2 == null) {
			return 0;
		}
		date2.setSeconds(0);
		date1.setSeconds(0);
		return (date2.getTime() - date1.getTime()) * 1.0 / (1000 * 60 * 60);
	}

	/**
	 * 计算两个日期所隔天数(粗略的天数)
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static Integer getDays(Date startDate, Date endDate) {
		if (startDate == null || endDate == null) {
			return 0;
		}
		// 先将时分移都去掉
		Date start = DateUtils.parseDate(DateUtils.formatDate(startDate, "yyyy-MM-dd"));
		Date end = DateUtils.parseDate(DateUtils.formatDate(endDate, "yyyy-MM-dd"));
		Long intervalDays = (end.getTime() - start.getTime()) / (24 * 3600 * 1000);
		return intervalDays.intValue();
	}

	/**
	 * 计算两个日期所隔分钟
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static long getMinutes(Date startDate, Date endDate) {
		if (startDate == null || endDate == null) {
			return 0;
		}
		startDate.setSeconds(0);
		endDate.setSeconds(0);
		return (endDate.getTime() - startDate.getTime()) / (1000 * 60);
	}

	public static String formatMinutes(Integer minutes) {
		String hh = "0";
		String mm = "0";
		Integer h = minutes / 60;
		Integer m = minutes % 60;
		hh = (hh + h).substring((hh + h).length() - 2, (hh + h).length());
		mm = (mm + m).substring((mm + m).length() - 2, (mm + m).length());
		return hh + ":" + mm + ":" + "00";
	}

	/**
	 * 获得传入月份的天数（cfei）
	 * 
	 * @param strDate
	 * @return
	 */
	public static int getCountMonthDays(String strDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		Calendar calendar = new GregorianCalendar();
		Date date;
		try {
			date = sdf.parse(strDate);
			calendar.setTime(date);
		} catch (ParseException e) {
			log.error(e);
		}
		int day = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		return day;
	}

	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_YEAR, -2);
		//System.out.println(getMinutes(cal.getTime(), new Date()));
		//System.out.println(getCountMonthDays("2010-02"));
	}
	

          public static long getDistanceTimes(String str1, String str2) {  
	       DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
	      Date one;  
	       Date two;  
	       long day = 0;  
	      long hour = 0;  
	       long min = 0;  
	       long sec = 0;  
	       try {  
	           one = df.parse(str1);  
	           two = df.parse(str2);  
	           long time1 = one.getTime();  
	          long time2 = two.getTime();  
	          long diff ;  
	           if(time1<time2) {  
	               diff = time2 - time1;  
	           } else {  
	               diff = time1 - time2;  
	          }  
	          day = diff / (24 * 60 * 60 * 1000);  
	           hour = (diff / (60 * 60 * 1000) - day * 24);  
	          min = ((diff / (60 * 1000)) - day * 24 * 60 - hour * 60);  
          sec = (diff/1000-day*24*60*60-hour*60*60-min*60);  
	       } catch (ParseException e) {  
	           e.printStackTrace();  
	      }  
	       return sec;  
	   }  

          
          /**
           * 两个时间相差距离多少天多少小时多少分多少秒
           * @param str1 时间参数 1 格式：1990-01-01 12:00:00
           * @param str2 时间参数 2 格式：2009-01-01 12:00:00
           * @return String 返回值为：xx天xx小时xx分xx秒
           */
          public static String getDistanceTime(String str1, String str2) {
              DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
              Date one;
              Date two;
              long day = 0;
              long hour = 0;
              long min = 0;
              long sec = 0;
              try {
                  one = df.parse(str1);
                  two = df.parse(str2);
                  long time1 = one.getTime();
                  long time2 = two.getTime();
                  long diff ;
                  if(time1<time2) {
                      diff = time2 - time1;
                  } else {
                      diff = time1 - time2;
                  }
                  day = diff / (24 * 60 * 60 * 1000);
                  hour = (diff / (60 * 60 * 1000) - day * 24);
                  min = ((diff / (60 * 1000)) - day * 24 * 60 - hour * 60);
                  sec = (diff/1000-day*24*60*60-hour*60*60-min*60);
              } catch (ParseException e) {
                  e.printStackTrace();
              }
              return day + "天" + hour + "小时" + min + "分" + sec + "秒";
          }

          /**
           * 两个时间相差距离多少天多少小时
           * @param str1 时间参数 1 格式：1990-01-01 12:00:00
           * @param str2 时间参数 2 格式：2009-01-01 12:00:00
           * @return String 返回值为：xx天xx小时
           */
          public static String getDistanceDayHouse(String str1, String str2) {
              DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
              Date one;
              Date two;
              long day = 0;
              long hour = 0;
              long min = 0;
              long sec = 0;
              try {
                  one = df.parse(str1);
                  two = df.parse(str2);
                  long time1 = one.getTime();
                  long time2 = two.getTime();
                  long diff ;
                  if(time1<time2) {
                      diff = time2 - time1;
                  } else {
                      diff = time1 - time2;
                  }
                  day = diff / (24 * 60 * 60 * 1000);
                  hour = (diff / (60 * 60 * 1000) - day * 24);
                  min = ((diff / (60 * 1000)) - day * 24 * 60 - hour * 60);
                  sec = (diff/1000-day*24*60*60-hour*60*60-min*60);
              } catch (ParseException e) {
                  e.printStackTrace();
              }
              return day + "天" + hour + "小时";
          }
          
          
          /**  
           * 功能：得到当前月份月初 格式为：xxxx-yy-zz (eg: 2007-12-01)  
           * @return String  
           * @author pure  
           */  
         public static String thisMonth(String dateStr) {   
             String strY = null;   
             Calendar localTime = Calendar.getInstance();
             localTime.setTime(parseDate(dateStr));
             x = localTime.get(Calendar.YEAR);   
             y = localTime.get(Calendar.MONTH) + 1;   
             strY = y >= 10 ? String.valueOf(y) : ("0" + y);return x + "-" + strY + "-01";   
         }   
         /**  
           * 功能：得到当前月份月底 格式为：xxxx-yy-zz (eg: 2007-12-31)  
           * @return String  
           * @author pure  
           **/  
         public static String thisMonthEnd(String dateStr) { 
        	 Calendar localTime = Calendar.getInstance();
        	 localTime.setTime(parseDate(dateStr));
             String strY = null;   
             String strZ = null;   
             boolean leap = false;   
             x = localTime.get(Calendar.YEAR);   
             y = localTime.get(Calendar.MONTH) + 1;   
             if (y == 1 || y == 3 || y == 5 || y == 7 || y == 8 || y == 10 || y == 12) {   
                 strZ = "31";   
             }   
             if (y == 4 || y == 6 || y == 9 || y == 11) {   
                 strZ = "30";   
             }   
             if (y == 2) {   
                 leap = leapYear(x);   
                 if (leap) {   
                     strZ = "29";   
                 }else {   
                     strZ = "28";   
                 }   
             }   
             strY = y >= 10 ? String.valueOf(y) : ("0" + y);   
             return x + "-" + strY + "-" + strZ;   
         }   
       
         /**  
           * 功能：得到当前季度季初 格式为：xxxx-yy-zz (eg: 2007-10-01)<br>  
           * @return String  
           * @author pure  
           */  
         public static String thisSeason(String dateStr) {  
        	 Calendar localTime = Calendar.getInstance();
        	 localTime.setTime(parseDate(dateStr));
             String dateString = "";   
             x = localTime.get(Calendar.YEAR);   
             y = localTime.get(Calendar.MONTH) + 1;   
             if (y >= 1 && y <= 3) {   
                 dateString = x + "-" + "01" + "-" + "01";   
             }   
             if (y >= 4 && y <= 6) {   
                 dateString = x + "-" + "04" + "-" + "01";   
             }   
             if (y >= 7 && y <= 9) {   
                 dateString = x + "-" + "07" + "-" + "01";   
             }   
             if (y >= 10 && y <= 12) {   
                 dateString = x + "-" + "10" + "-" + "01";   
             }   
             return dateString;   
             }   
       
         /**  
           * 功能：得到当前季度季末 格式为：xxxx-yy-zz (eg: 2007-12-31)<br>  
           * @return String  
           * @author pure  
           */  
         public static String thisSeasonEnd(String dateStr) { 
        	 Calendar localTime = Calendar.getInstance();
        	 localTime.setTime(parseDate(dateStr));
             String dateString = "";   
             x = localTime.get(Calendar.YEAR);   
             y = localTime.get(Calendar.MONTH) + 1;   
             if (y >= 1 && y <= 3) {   
                 dateString = x + "-" + "03" + "-" + "31";   
             }   
             if (y >= 4 && y <= 6) {   
                 dateString = x + "-" + "06" + "-" + "30";   
             }   
             if (y >= 7 && y <= 9) {   
                 dateString = x + "-" + "09" + "-" + "30";   
             }   
             if (y >= 10 && y <= 12) {   
                 dateString = x + "-" + "12" + "-" + "31";   
             }   
             return dateString;   
         }    
         
         /**  
          * 功能：判断输入年份是否为闰年<br>  
          * @param year  
          * @return 是：true  否：false  
          * @author pure  
          */  
        public static boolean leapYear(int year) {   
            boolean leap;   
            if (year % 4 == 0) {   
                if (year % 100 == 0) {   
                    if (year % 400 == 0) leap = true;   
                        else leap = false;   
                    }   
                else leap = true;   
            }   
            else leap = false;   
            return leap;   
        }
        
        /**
         * 毫秒转时分秒
         * @param ms
         * @return
         */
        public static String getTimeByMs(Long ms)
        {
        	long hour = ms/(60*60*1000);
        	long minute = (ms - hour*60*60*1000)/(60*1000);
        	long second = (ms - hour*60*60*1000 - minute*60*1000)/1000;
        	if(second >= 60 )
        	{
        	  second = second % 60;
        	  minute+=second/60;
        	}
        	if(minute >= 60)
        	{
        	  minute = minute %60;
        	  hour += minute/60;
        	}
        	String sh = "";
        	String sm ="";
        	String ss = "";
        	if(hour <10)
        	{
        	   sh = "0" + String.valueOf(hour);
        	}else
        	{
        	   sh = String.valueOf(hour);
        	}
        	if(minute <10)
        	{
        	   sm = "0" + String.valueOf(minute);
        	}else
        	{
        	   sm = String.valueOf(minute);
        	}
        	if(second <10)
        	{
        	   ss = "0" + String.valueOf(second);
        	}else
        	{
        	   ss = String.valueOf(second);
        	}
        	System.out.println(sh +":"+ sm +":"+ ss);
        	return sh +":"+ sm +":"+ ss;
        }
}
