package com.sise.framework.utils;

import java.util.UUID;

public class StringUtils {
	public static String getUUID()
	{
	     UUID uuid = UUID.randomUUID();
	     String[] uuids = uuid.toString().split("-");
	     String result = "" ;
	     for(String str:uuids)
	     {
	    	 result+=str;
	     }
		return result;
	}
}
