package com.sise.framework.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import com.sise.framework.common.ConfigContext;

public class FileUtils {
	
	/**
	 * 上传文件
	 * @param files File文件类集合
	 * @param filesFileName 文件名集合
	 * @param filesContentType 文件类型集合
	 * @param createFileName 创建文件夹名
	 * @return
	 */
	public static List<JSONObject> uploadFile(List<File> files,List<String> filesFileName,List<String> filesContentType,String createFileName)
	{
		String path = ConfigContext.UPLOAD_ULR+createFileName+"/";//盘符+年月日+四位随机码
		List<JSONObject> jsonObjects = new ArrayList<JSONObject>();
		for(int i = 0;i<files.size();i++)
		{
			JSONObject jsonObject = new JSONObject();
			String fileName = filesFileName.get(i);//文件名
			jsonObject.element("fileType", fileName.substring(fileName.indexOf(".")+1, fileName.length()));
			jsonObject.element("fileName", fileName);
			jsonObject.element("path", path);
			InputStream fis = null;
			OutputStream ops = null;
			try
			{
				//判断文件夹是否存在，不存在的创建
				File destFile = new File(path);
				if(!destFile.exists()){
					destFile.mkdirs();
				}
				File inFile = files.get(i);
				fis = new FileInputStream(inFile);
				File outFile = new File(path+fileName);
				ops = new FileOutputStream(outFile);
				int byteLenght = 0;
				byte[] b = new byte[1024];
				int length = 0;
				while ((length = fis.read(b)) > 0) {
					byteLenght+=length;
					ops.write(b, 0, length);
				}
				ops.flush();
				jsonObject.element("size", byteLenght);
				jsonObjects.add(jsonObject);
//				IOUtils.copy(fis, ops);//输入流读入，输出流写出
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}finally {
				if(fis!=null)
					if(ops!=null)
						try {
							ops.close();
							fis.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			}
		}
		return jsonObjects;
	}
}
