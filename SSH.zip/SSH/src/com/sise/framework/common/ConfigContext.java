package com.sise.framework.common;

public class ConfigContext {
	public static String UPLOAD_ULR = "/Users/zhoujingwei/Desktop/";
}
