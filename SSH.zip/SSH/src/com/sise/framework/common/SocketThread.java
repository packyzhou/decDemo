/**
 * 
 */
package com.sise.framework.common;

import java.io.IOException;
import java.net.Socket;
import java.util.Date;

import com.sise.framework.utils.DateUtils;

/**
 * 推送新工单访问socket线程
 * Copyright 2012 by Grgbanking
 * All Rights Reserved.
 * Author: zjwei
 * Date: 2012-5-24 上午10:26:00
 */
public class SocketThread {
	
	
	/**socket对象*/
	private Socket socket;
	
	
	public void sendWorkFormList()
	{
		new Thread(new Runnable()
		{
			public void run() {
				try {
					/**创建Socket对象,地址与端口要对应服务器的值*/
					while(true)
					{
							
						if(socket==null)
						{
							socket = new Socket("192.168.1.102", 9999);			
							socket.getOutputStream().write(("地区为地区").getBytes("UTF-8"));
							System.out.println("已发送。。。");
						}
					}
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					try {socket.getOutputStream().close();socket.close();
					} catch (IOException e) {e.printStackTrace();}
				}
			}
		}).start();
	}
	
	public static void main(String args[])
	{
		SocketThread thread = new SocketThread();
		thread.sendWorkFormList();
	}
}
