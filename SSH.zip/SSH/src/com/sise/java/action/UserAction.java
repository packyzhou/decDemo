package com.sise.java.action;

public class UserAction {

}
