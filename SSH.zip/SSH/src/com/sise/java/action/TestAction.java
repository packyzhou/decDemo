package com.sise.java.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.sise.framework.utils.AjaxUtils;
import com.sise.framework.utils.DateUtils;
import com.sise.framework.utils.NumberUtils;
import com.sise.framework.web.BaseAction;

public class TestAction extends BaseAction{
	// 如果做文件上传时，表单的文件域名必须是files
	protected List<File> file;
	// 上传临时文件的文件名
	protected List<String> fileFileName;
	// 上传文件contentType类型
	protected List<String> fileContentType;	
	
	public void getTestMsg()
	{
		String requestMsg = request.getParameter("msg");
		
//		System.out.println("请求数据："+requestMsg);
		String responseMsg = createJSON();
		AjaxUtils.renderText(responseMsg);
		
	}
	private String createJSON()
	{
		JSONObject jsonResult = new JSONObject();
		List<JSONObject> users = new ArrayList<JSONObject>();
		for(int i = 0 ;i<5; i++)
		{
			JSONObject json = new JSONObject();
			json.element("userId", i);
			json.element("name", "packy_"+i);
			json.element("password", i+1323);
			users.add(json);
		}
		jsonResult.element("Users", users);
		return jsonResult.toString();
	}
	
	private String createXML()
	{
		String xmlStr = "";
		Document document = DocumentHelper.createDocument();
		Element rootElement = document.addElement("Users");
		Element userElement = rootElement.addElement("User");
		Element nameNode = userElement.addElement("name");
		Element passwordNode = userElement.addElement("password");
		nameNode.addText("packy");
		userElement.addAttribute("id", "1");
		passwordNode.addText("1234567");
		
		Element userElement2 = rootElement.addElement("User");
		Element nameNode2 = userElement2.addElement("name");
		Element passwordNode2 = userElement2.addElement("password");
		nameNode2.addText("packy2");
		userElement2.addAttribute("id", "2");
		passwordNode2.addText("5555555");
		
		
		xmlStr = document.asXML();
		return xmlStr;
	}
	
	public void upLoadImage()
	{
		String fileName = DateUtils.getDate("yyyyMMddHHmmss")+NumberUtils.getRandom(4)+".jpg";//文件名
		String upPath = "D:/upload/";
		byte[] bs=null;
		try {
			String uploadPath = upPath+ DateUtils.getDate("yyyyMM") + "/";//文件目录
			if(null != file.get(0)){
			File tempFile = file.get(0);
			
				
				InputStream is = null;
				OutputStream ops = null;
				try {
					is = new FileInputStream(tempFile);
					
					File destDir=new File(uploadPath);
					if(!destDir.exists()){
						destDir.mkdirs();
					}
					File destFile = new File(uploadPath+fileName);
					ops = new FileOutputStream(destFile);
					IOUtils.copy(is, ops);
					
				} catch (Exception ex) {
					ex.printStackTrace();
				} finally {
					IOUtils.closeQuietly(is);
					IOUtils.closeQuietly(ops);
				}
				
		
			File file111 = new File(uploadPath+fileName);
			
			bs = IOUtils.toByteArray(new FileInputStream(file111));
			
			
//			response.sendRedirect(new String(Base64.encode("{\"status\":\"1\",\"errMsg\":\"上传成功！\"}".getBytes("UTF-8"))));
			AjaxUtils.renderSuccess("上传成功！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			AjaxUtils.renderSuccess("上传失败！");
		}
	}

	public List<File> getFile() {
		return file;
	}

	public void setFile(List<File> file) {
		this.file = file;
	}

	public List<String> getFileFileName() {
		return fileFileName;
	}

	public void setFileFileName(List<String> fileFileName) {
		this.fileFileName = fileFileName;
	}

	public List<String> getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(List<String> fileContentType) {
		this.fileContentType = fileContentType;
	}
	
}
