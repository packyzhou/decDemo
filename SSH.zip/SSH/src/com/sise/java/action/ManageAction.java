package com.sise.java.action;

import java.io.File;
import java.util.List;

import com.sise.framework.utils.AjaxUtils;
import com.sise.framework.web.BaseAction;

public class ManageAction extends BaseAction {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 如果做文件上传时，表单的文件域名必须是files
		protected List<File> file;
		// 上传临时文件的文件名
		protected List<String> fileFileName;
		// 上传文件contentType类型
		protected List<String> fileContentType;
		public List<File> getFile() {
			return file;
		}
		public void setFile(List<File> file) {
			this.file = file;
		}
		public List<String> getFileFileName() {
			return fileFileName;
		}
		public void setFileFileName(List<String> fileFileName) {
			this.fileFileName = fileFileName;
		}
		public List<String> getFileContentType() {
			return fileContentType;
		}
		public void setFileContentType(List<String> fileContentType) {
			this.fileContentType = fileContentType;
		}	
		
		private String serverAddress;
		
		
		public String getServerAddress() {
			return serverAddress;
		}
		public void setServerAddress(String serverAddress) {
			this.serverAddress = serverAddress;
		}
		/**
		 * 跳转打包管理页面
		 * @return
		 */
		public String toManagePage(){
			return dispatcher("/jsp/package_manage.jsp");
		}
		
		public void doPackage(){
			System.out.println("服务器地址："+serverAddress);
			System.out.println("文件名："+fileFileName);
			String phex = fileFileName.get(0).split("\\.")[1];
			this.uploadFile("test."+phex, file);
		}
}
