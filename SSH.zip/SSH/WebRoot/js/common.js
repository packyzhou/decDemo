
/**
* 根据广电银通客户服务系统需求，定制一些JS公用方法
* created by zhangzhi
*/

Common={
	/*获取随机数*/
	getRandom:function(n){
		return Math.floor(Math.random()*Math.pow(10,n));
	},
	userSelect:function(id,name,p){  //p格式为argument=232&groupIds=1,2&userIds=1214&roleCodes=ROLE_MANGER
		if (p == undefined){
			p="";
		}
		return Common.dialog({url:ctx+"/user!select.do?id="+id+"&name="+name+"&"+p,width:500,height:500,winName:"userWindow"});
	},
	userSingleSelect:function(id,name,p){//p格式为argument=232&groupIds=1,2&userIds=1214&roleCodes=ROLE_MANGER
		if (p == undefined){
			p="";
		}
		return Common.dialog({url:ctx+"/user!selectSingleUser.do?id="+id+"&name="+name+"&"+p,width:300,height:400,winName:"userWindow"});
	},
	groupSelect:function(p){  //
		if (p == undefined){
			p="";
		}
		return Common.dialog({url:ctx+"/group!selectGroup.do?type=s&"+p,width:250,height:400,winName:"userWindow"});
	},
	groupSingleSelect:function(p){  //
		if (p == undefined){
			p="";
		}
		return Common.dialog({url:ctx+"/group!selectGroup.do?type=&"+p,width:250,height:400,winName:"userWindow"});
	},
	postionSelect:function(id,name,positionRank){  //
		if (id == undefined){
			id="";
		}
		return Common.dialog({url:ctx+"/user!toPositionList.do?id="+id+"&name="+name+"&positionRank="+positionRank,width:700,height:400,winName:"postionWindow"});
	},
	orgSelect:function(p){  //
		if (p == undefined){
			p="";
		}
		return Common.dialog({url:ctx+"/organization!selectOrg.do?type=s&"+p,width:250,height:400,winName:"userWindow"});
	},
	orgSingleSelect:function(p){  //
		if (p == undefined){
			p="";
		}
		return Common.dialog({url:ctx+"/organization!selectOrg.do?type=&"+p,width:250,height:400,winName:"userWindow"});
	},
	roleSelect:function(p){  //
		if (p == undefined){
			p="";
		}
		return Common.dialog({url:ctx+"/role!roleSelect.do?"+p,width:250,height:400,winName:"userWindow"});
	},
	roleOfMaSelect:function(p){  //
		if (p == undefined){
			p="";
		}
		return Common.dialog({url:ctx+"/role!roleOfMaSelect.do?"+p,width:250,height:400,winName:"userWindow"});
	},
	/*将表单项转换成JSON对象，用于datagrid查询参数*/
	fieldtoJson:function(formId){
		var form=$('#'+formId);
		search = true;
		//去掉输入框所有空格
		$.each($("#"+formId+" input[type='text']"),function(index,input){
			input.value=input.value.replace(/[ ]/g,""); 
		});
		var queryStringArray =form.formSerialize().split("&");
		var obj={};
		$.each(queryStringArray, function(index, param){
			  var paramArray=param.split("=");
			  var values= decodeURI(paramArray[1]);
			  values=values.replace(new RegExp("%2C","gm"),",").replace(new RegExp("%2F","gm"),"/");
			  if(typeof(eval("obj."+paramArray[0]))=='undefined'){
				  eval("obj."+paramArray[0]+"=\""+values+"\"");
			  }else{
				  eval("obj."+paramArray[0]+"=obj."+paramArray[0]+"+\",\"+\""+values+"\"");
			  }
		});
		obj.doSearch="true";
		return obj;
	},
	dialog:function(properties){
		var width=500;
		var height=300;
		var modal = true;
		var edge="raised";
		var resizable="yes";
		var scroll="yes";
		var status="no";
		var center="yes";
		var help="no";
		var minimize="yes";
		var maximize="yes";
		var location="no";
		var winName = "_blank";
		var url=properties.url;
		var argument=null;//参数对象
		if (properties.width != undefined)
			width = properties.width;
		if (properties.height != undefined)
			height = properties.height;
		if (properties.edge != undefined)
			edge = properties.edge;
		if (properties.resizable != undefined)
			resizable = properties.resizable;
		if (properties.scroll != undefined)
			scroll = properties.scroll;
		if (properties.status != undefined)
			status = properties.status;
		if (properties.center != undefined)
			center = properties.center;
		if (properties.help != undefined)
			help = properties.help;
		if (properties.minimize != undefined)
			minimize = properties.minimize;
		if (properties.maximize != undefined)
			maximize = properties.maximize;
		if (properties.argument != undefined)
			argument = properties.argument;
		if (properties.winName != undefined)
			winName = properties.winName;
		if (properties.modal != undefined)
			modal = properties.modal;
		var iTop = (window.screen.availHeight - 20 - height) / 2;
        var iLeft = (window.screen.availWidth - 10 - width) / 2;
		if (properties.iTop != undefined)
			iTop = properties.iTop;
		if (properties.iLeft != undefined)
			iLeft = properties.iLeft;
        if(modal){
        	return window.showModalDialog(url,window,"dialogLeft="+iLeft+";dialogTop="+iTop+";dialogWidth:"+width+"px;dialogHeight:"+height+"px;edge:"+edge+";resizable:"+resizable+";scroll:"+scroll+";status:"+status+";center:"+center+";help:"+help+";minimize:"+minimize+";maximize:"+maximize+";");
        }else{
        	return window.open(url,winName,'height='+height+',width='+width+',top='+iTop+',left='+iLeft+',toolbar=no,menubar=no,scrollbars='+scroll+', resizable='+resizable+',location='+location+', status='+status);
        }
	},
	baseDialog:function(properties){
		var width=500;
		var height=300;
		var title = "对话框";
		var modal = true;
		var winName = "_blank";
		var resizable="yes";
		var scroll="yes";
		var status="no";
		var location="no";
		var readOnly = false;
		var url=properties.url;
		if (properties.width != undefined)
			width = properties.width;
		if (properties.height != undefined)
			height = properties.height;
		if (properties.title != undefined)
			title = properties.title;
		if (properties.readOnly != null)
			readOnly = properties.readOnly;
		 if(modal){
				if(readOnly)
				{
					$('#dlg').dialog({ 
						 title:title,
						 width:width,
						 height:height
			         });  
				}else
				{
				 $('#dlg').dialog({ 
					 title:title,
					 width:width,
					 height:height,
		             buttons:[{  
		                 text:'保存',  
		                 iconCls:'icon-ok',  
		                 handler:function(){  
		                     window.frames["dialogFrame"].save(); 
		                    // window.frames["dialogFrame"].document.forms["form"].submit();
		                 }  
		             },{  
		                 text:'取消',  
		                 iconCls:'icon-cancel', 
		                 handler:function(){  
		                     $('#dlg').dialog('close');  
		                 }  
		             }]  
		         });  
				}
				 $('#dialogFrame').attr("src",url);
				 $('#dlg').dialog('open');
		 }else{
	        	return window.open(url,winName,'height='+height+',width='+width+',toolbar=no,menubar=no,scrollbars='+scroll+', resizable='+resizable+',location='+location+', status='+status);
	     }
	},
	endwith:function(str,s){
		  if(s==null||s==""||str.length==0||s.length>str.length)
			     return false;
			  if(str.substring(str.length-s.length)==s)
			     return true;
			  else
			     return false;
			  return true;
	 },
	 startwith:function(str,s){
		  if(s==null||s==""||str.length==0||s.length>str.length)
			   return false;
			  if(str.substr(0,s.length)==s)
			     return true;
			  else
			     return false;
			  return true;
	}

}



